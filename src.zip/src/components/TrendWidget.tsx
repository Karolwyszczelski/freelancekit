// components/TrendWidget.tsx
'use client'

import { Canvas } from '@react-three/fiber'
import { OrbitControls, Torus, GradientTexture } from '@react-three/drei'
import * as THREE from 'three'
import { useState, useEffect, useMemo } from 'react'
import { supabase } from '../lib/supabaseClient'

interface TrendRow { name: string; value: number }
interface Slice     { name: string; value: number; colorFrom: string; colorTo: string }

export default function TrendWidget() {
  const [trends, setTrends] = useState<TrendRow[]>([])

  // fetch i realtime jak wcześniej…
  const fetchTrends = async () => {
    const { data } = await supabase.from<TrendRow>('trends').select('name,value')
    if (data) setTrends(data)
  }
  useEffect(() => {
    fetchTrends()
    const ch = supabase
      .channel('realtime-trends')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trends' }, fetchTrends)
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [])

  // fallback
  const raw = trends.length > 0
    ? trends
    : [
        { name: 'AI Copywriting',   value: 35 },
        { name: '3D Design',        value: 25 },
        { name: 'Marketing Autom.', value: 40 },
      ]

  // palette + slices
  const slices: Slice[] = useMemo(() => {
    const pal = [
      ['#22c55e','#10b981'],
      ['#3b82f6','#6366f1'],
      ['#facc15','#fbbf24'],
    ]
    return raw.map((t,i) => ({
      name: t.name, value: t.value,
      colorFrom: pal[i%pal.length][0],
      colorTo:   pal[i%pal.length][1],
    }))
  }, [raw])

  const total = useMemo(() => slices.reduce((s,x) => s + x.value, 0), [slices])
  if (total === 0) return null

  const segments = useMemo(() => {
    let cur = 0
    return slices.map(s => {
      const angle = (s.value/total)*Math.PI*2
      const seg = { ...s, start: cur, angle }
      cur += angle
      return seg
    })
  }, [slices, total])

  return (
    <div className="relative w-full h-80 rounded-3xl overflow-hidden">
      {/* 3D Canvas */}
      <Canvas
        orthographic
        camera={{ position: [0,0,12], zoom: 30 }}
        className="absolute inset-0"
      >
        <ambientLight intensity={0.6} />
        <directionalLight position={[5,5,5]} intensity={1} />
        <group rotation={[-Math.PI/6,0,0]}>
          {segments.map((seg,i) => (
            <Torus
              key={i}
              args={[3, 0.8, 64, 300, seg.angle]}    /* grubszy tubeRadius i więcej segmentów */
              rotation={[0,0,-seg.start - seg.angle/2]}
            >
              <meshStandardMaterial
                transparent side={THREE.DoubleSide}
                roughness={0.1} metalness={0.5}
              >
                <GradientTexture
                  attach="map"
                  stops={[0,1]}
                  colors={[seg.colorFrom, seg.colorTo]}
                  size={2048}
                />
              </meshStandardMaterial>
            </Torus>
          ))}
        </group>
        <OrbitControls enableZoom={false} enablePan={false} />
      </Canvas>

      {/* Overlay z listą */}
      <div className="
          absolute bottom-4 right-4
          w-40 p-4
          bg-white/10 backdrop-blur-lg
          border border-white/20
          rounded-2xl
          text-white
        ">
        <h3 className="text-base font-semibold mb-2">Trendy 2025</h3>
        <ul className="space-y-1 text-sm">
          {slices.map((s,i) => (
            <li key={i} className="flex justify-between">
              <span className="truncate">{s.name}</span>
              <span>{s.value}%</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
