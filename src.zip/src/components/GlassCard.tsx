// components/GlassCard.tsx
export function GlassCard({
  children,
  className = '',
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={`
        relative w-full h-full
        bg-white/10 backdrop-blur-lg
        border border-white/20
        rounded-2xl
        overflow-hidden
        ${className}
      `}
    >
      {children}
    </div>
  )
}
