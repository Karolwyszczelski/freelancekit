import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'

export default function Step5SeoSlug() {
  const { state, setState } = usePortfolioWizard()
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">SEO & Adres strony</h2>
      <div className="flex flex-col gap-3 max-w-md mx-auto">
        <input placeholder="Tytuł strony (SEO Title)"
               value={state.seo.title}
               onChange={e => setState((p) => ({...p, seo: {...p.seo, title: e.target.value}}))}
               className="rounded-xl px-4 py-2 bg-white/60"/>
        <input placeholder="Opis strony (SEO description)"
               value={state.seo.description}
               onChange={e => setState((p) => ({...p, seo: {...p.seo, description: e.target.value}}))}
               className="rounded-xl px-4 py-2 bg-white/60"/>
        <input placeholder="Adres (np. /KamilKowalczyk)" value={state.customSlug}
               onChange={e => setState((p) => ({...p, customSlug: e.target.value.replace(/[^a-zA-Z0-9_-]/g, '') }))}
               className="rounded-xl px-4 py-2 bg-white/60"/>
        <div className="text-xs text-gray-500 mt-1">
          Twój adres: <span className="font-mono text-purple-600">https://freelancekit.pl/{state.customSlug || 'twoja-nazwa'}</span>
        </div>
      </div>
    </div>
  )
}
