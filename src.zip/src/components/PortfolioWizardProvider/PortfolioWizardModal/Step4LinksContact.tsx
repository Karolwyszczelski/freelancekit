import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'

const socialTypes = [
  { label: "LinkedIn", icon: "in" }, { label: "GitHub", icon: "gh" }, { label: "Instagram", icon: "ig" }, { label: "Facebook", icon: "fb" },
]

export default function Step4LinksContact() {
  const { state, setState } = usePortfolioWizard()
  const { links } = state

  function handleSocial(idx, field, val) {
    const copy = [...links.socials]
    copy[idx][field] = val
    setState((prev) => ({
      ...prev,
      links: { ...prev.links, socials: copy }
    }))
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Linki & Kontakt</h2>
      <div className="flex flex-col gap-3 max-w-md mx-auto">
        <input placeholder="Email" value={links.email} onChange={e => setState((p) => ({...p, links: {...p.links, email: e.target.value}}))}
               className="rounded-xl px-4 py-2 bg-white/60"/>
        <input placeholder="Telefon (opcjonalnie)" value={links.phone} onChange={e => setState((p) => ({...p, links: {...p.links, phone: e.target.value}}))}
               className="rounded-xl px-4 py-2 bg-white/60"/>
        <div>
          <div className="mb-2">Social media:</div>
          {links.socials.map((s, idx) => (
            <div key={idx} className="flex gap-2 items-center mb-1">
              <select value={s.type} onChange={e => handleSocial(idx, 'type', e.target.value)}
                      className="px-2 py-1 rounded bg-white/70 border border-gray-300 text-sm">
                <option value="">Wybierz</option>
                {socialTypes.map(st => <option value={st.label} key={st.label}>{st.label}</option>)}
              </select>
              <input placeholder="Link (https://...)" value={s.url} onChange={e => handleSocial(idx, 'url', e.target.value)}
                     className="rounded px-2 py-1 bg-white/70 border border-gray-200 text-sm flex-1"/>
              <button type="button" onClick={() => setState((prev) => ({
                ...prev,
                links: { ...prev.links, socials: prev.links.socials.filter((_, j) => j !== idx) }
              }))} className="text-red-400 text-xs">Usuń</button>
            </div>
          ))}
          <button type="button" onClick={() => setState((prev) => ({
            ...prev,
            links: { ...prev.links, socials: [...prev.links.socials, {type: "", url: ""}] }
          }))} className="mt-1 px-2 py-1 rounded bg-blue-100 text-blue-700 text-xs">Dodaj social</button>
        </div>
      </div>
    </div>
  )
}
