import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'

// Przykładowe szablony (dodasz własne layouty)
const templates = [
  { name: "Klasyczny", desc: "Klasyczny, sekcyjny layout, duży avatar" },
  { name: "Hero", desc: "Nowoczesny, hero z bio, projekty niżej" },
  { name: "Minimal", desc: "Minimalistyczny, dużo bieli, proste bloki" },
]

export default function Step1ChooseTemplate() {
  const { state, setState } = usePortfolioWizard()
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Wybierz szablon</h2>
      <div className="flex gap-4 justify-center">
        {templates.map((t, i) => (
          <label key={i} className={`rounded-2xl border-2 p-4 min-w-[180px] cursor-pointer transition-all flex-1 flex flex-col items-center 
            ${state.template === i ? "border-purple-600 bg-white shadow-lg" : "border-transparent bg-white/30 hover:border-purple-300"}
          `}>
            <input type="radio" name="template" className="hidden"
              checked={state.template === i}
              onChange={() => setState((prev) => ({ ...prev, template: i }))}
            />
            <div className="text-xl font-bold mb-1">{t.name}</div>
            <div className="text-gray-500 text-sm mb-2">{t.desc}</div>
            {state.template === i && <div className="text-purple-600 font-semibold">Wybrany</div>}
          </label>
        ))}
      </div>
    </div>
  )
}
