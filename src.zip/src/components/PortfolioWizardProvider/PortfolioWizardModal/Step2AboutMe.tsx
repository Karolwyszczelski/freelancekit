import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'
import { useRef } from 'react'

export default function Step2AboutMe() {
  const { state, setState } = usePortfolioWizard()
  const { about } = state
  const fileRef = useRef<HTMLInputElement>(null);

  function handleChange(e) {
    setState((prev) => ({
      ...prev,
      about: { ...prev.about, [e.target.name]: e.target.value }
    }))
  }

  function handleFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setState((prev) => ({
      ...prev,
      about: { ...prev.about, avatar: file, avatarUrl: url }
    }))
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">O mnie</h2>
      <div className="flex flex-col gap-3 max-w-md mx-auto">
        <input name="name" placeholder="Imię i nazwisko" value={about.name} onChange={handleChange}
               className="rounded-xl px-4 py-2 bg-white/60" />
        <input name="headline" placeholder="Nagłówek/hasło (np. Frontend Developer)"
               value={about.headline} onChange={handleChange} className="rounded-xl px-4 py-2 bg-white/60"/>
        <textarea name="bio" placeholder="Krótko o sobie (max 200 znaków)" maxLength={200}
                  value={about.bio} onChange={handleChange} className="rounded-xl px-4 py-2 bg-white/60 min-h-[60px]"/>
        <div className="flex items-center gap-3">
          <input type="file" ref={fileRef} accept="image/*" onChange={handleFile} className="hidden"/>
          <button type="button" onClick={() => fileRef.current?.click()}
                  className="px-3 py-1 rounded-lg bg-purple-500 text-white">Wgraj zdjęcie</button>
          {about.avatarUrl && <img src={about.avatarUrl} className="w-12 h-12 rounded-full object-cover" alt="avatar" />}
        </div>
      </div>
    </div>
  )
}
