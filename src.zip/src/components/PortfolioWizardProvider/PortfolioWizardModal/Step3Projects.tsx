import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'
import { useState } from 'react'

export default function Step3Projects() {
  const { state, setState } = usePortfolioWizard()
  const [project, setProject] = useState({ title: '', desc: '', image: null, imageUrl: '', link: '', tags: '' })

  function handleAdd() {
    if (!project.title) return
    setState((prev) => ({
      ...prev,
      projects: [
        ...prev.projects,
        { ...project, tags: project.tags.split(',').map(t => t.trim()) }
      ]
    }))
    setProject({ title: '', desc: '', image: null, imageUrl: '', link: '', tags: '' })
  }

  function handleImage(e) {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file)
    setProject(p => ({ ...p, image: file, imageUrl: url }))
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Projekty</h2>
      <div className="flex flex-col gap-2 max-w-md mx-auto">
        <input placeholder="Tytuł projektu" value={project.title}
               onChange={e => setProject(p => ({ ...p, title: e.target.value }))} className="rounded-xl px-3 py-2 bg-white/60"/>
        <textarea placeholder="Opis (krótki)" value={project.desc}
                  onChange={e => setProject(p => ({ ...p, desc: e.target.value }))} className="rounded-xl px-3 py-2 bg-white/60"/>
        <input placeholder="Link do projektu (https://…)" value={project.link}
               onChange={e => setProject(p => ({ ...p, link: e.target.value }))} className="rounded-xl px-3 py-2 bg-white/60"/>
        <input placeholder="Tagi (np. React, TypeScript)" value={project.tags}
               onChange={e => setProject(p => ({ ...p, tags: e.target.value }))} className="rounded-xl px-3 py-2 bg-white/60"/>
        <div className="flex items-center gap-2">
          <input type="file" accept="image/*" onChange={handleImage} />
          {project.imageUrl && <img src={project.imageUrl} className="w-10 h-10 rounded-md object-cover" alt="preview" />}
        </div>
        <button type="button" onClick={handleAdd}
                className="px-4 py-2 rounded-lg bg-blue-600 text-white">Dodaj projekt</button>
      </div>
      {/* Lista dodanych projektów */}
      <div className="mt-6 grid gap-3">
        {state.projects.map((p, i) => (
          <div key={i} className="bg-white/70 rounded-xl px-4 py-3 flex flex-col">
            <div className="font-semibold">{p.title}</div>
            <div className="text-gray-600 text-sm">{p.desc}</div>
            {p.imageUrl && <img src={p.imageUrl} className="w-14 h-14 mt-1 rounded-md object-cover" />}
            <div className="text-blue-600 text-xs">{p.link}</div>
            <div className="text-xs text-gray-500 mt-1">Tagi: {p.tags?.join(', ')}</div>
            <button className="ml-auto mt-2 text-red-400 text-xs"
                    onClick={() => setState((prev) => ({
                      ...prev,
                      projects: prev.projects.filter((_, j) => i !== j)
                    }))}
            >Usuń</button>
          </div>
        ))}
      </div>
    </div>
  )
}
