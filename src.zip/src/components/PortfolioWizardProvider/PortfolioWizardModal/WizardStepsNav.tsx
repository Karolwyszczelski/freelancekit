import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'

export default function WizardStepsNav() {
  const { state, setState } = usePortfolioWizard()
  const steps = [
    "Wybierz szablon", "O mnie", "Projekty", "Linki / Kontakt", "SEO i adres", "Podgląd"
  ];
  return (
    <nav className="flex gap-2 mb-8 justify-center text-sm select-none">
      {steps.map((step, idx) => (
        <button
          key={step}
          className={`px-2 py-1 rounded-full border 
            ${state.step === idx+1 ? "bg-purple-600 text-white border-purple-700 shadow" : "bg-white/30 text-gray-600 border-transparent"}
          `}
          onClick={() => setState((prev) => ({ ...prev, step: idx+1 }))}
          type="button"
        >
          <span className="font-semibold">{idx+1}</span> {step}
        </button>
      ))}
    </nav>
  );
}
