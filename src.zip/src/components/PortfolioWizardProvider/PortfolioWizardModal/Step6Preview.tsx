import { usePortfolioWizard } from '../../../app/portfolio-wizard/PortfolioWizardContext'

export default function Step6Preview({ onPublish }) {
  const { state, setState } = usePortfolioWizard()
  const { about, projects, links, template, seo, customSlug } = state
  // Wyświetl wybrany layout
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Podgląd Twojej strony</h2>
      <div className="rounded-2xl border bg-white/90 max-w-2xl mx-auto p-6 shadow-xl">
        <div className="flex gap-4 items-center mb-4">
          {about.avatarUrl && <img src={about.avatarUrl} className="w-20 h-20 rounded-full object-cover" />}
          <div>
            <div className="text-2xl font-bold">{about.name}</div>
            <div className="text-purple-700">{about.headline}</div>
            <div className="text-gray-500">{about.bio}</div>
          </div>
        </div>
        {projects.length > 0 && (
          <div className="mb-6">
            <div className="text-lg font-semibold mb-2">Projekty</div>
            <div className="grid gap-3">
              {projects.map((p, i) => (
                <div key={i} className="p-3 rounded-xl bg-purple-100 flex flex-col md:flex-row gap-3 items-center">
                  {p.imageUrl && <img src={p.imageUrl} className="w-16 h-16 object-cover rounded-lg" />}
                  <div>
                    <div className="font-semibold">{p.title}</div>
                    <div className="text-gray-600 text-sm">{p.desc}</div>
                    <div className="text-xs text-blue-700">{p.link}</div>
                    <div className="text-xs text-gray-500 mt-1">Tagi: {p.tags?.join(', ')}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="mb-2">
          <div className="text-lg font-semibold mb-1">Kontakt</div>
          <div className="text-sm text-gray-700">{links.email}</div>
          {links.phone && <div className="text-sm text-gray-700">{links.phone}</div>}
          <div className="flex gap-2 mt-2">
            {links.socials.filter(s => s.type && s.url).map((s, i) => (
              <a key={i} href={s.url} target="_blank" rel="noopener" className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700 hover:underline">{s.type}</a>
            ))}
          </div>
        </div>
      </div>
      <div className="flex justify-center gap-3 mt-8">
        <button className="px-8 py-3 rounded-xl bg-purple-600 text-white text-lg font-bold" onClick={onPublish}>
          Publikuj portfolio!
        </button>
        <button className="px-4 py-3 rounded-xl bg-gray-200 text-gray-700" onClick={() => setState((p) => ({...p, step: 1}))}>
          Edytuj od początku
        </button>
      </div>
      <div className="text-center text-sm text-gray-500 mt-4">
        Adres: <span className="text-purple-600 font-mono">https://freelancekit.pl/{customSlug || 'twoja-nazwa'}</span>
      </div>
    </div>
  )
}
