export function PortfolioTemplateClassic({ fullName, jobTitle, bio, projects, socials, contact }) {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="py-12 text-center bg-gradient-to-r from-blue-200 to-purple-200">
        <h1 className="text-4xl font-bold">{fullName}</h1>
        <p className="text-xl mt-2">{jobTitle}</p>
      </header>
      <main className="max-w-2xl mx-auto p-8">
        <section className="mb-8">
          <h2 className="font-bold text-2xl mb-2">O mnie</h2>
          <p>{bio}</p>
        </section>
        <section className="mb-8">
          <h2 className="font-bold text-2xl mb-2">Portfolio</h2>
          <ul className="space-y-4">
            {projects?.map((prj, i) => (
              <li key={i} className="p-4 border rounded-lg bg-white">
                <div className="font-semibold">{prj.title}</div>
                <div className="text-sm text-gray-600">{prj.desc}</div>
                {prj.link && <a href={prj.link} className="text-blue-500 underline" target="_blank">Zobacz</a>}
              </li>
            ))}
          </ul>
        </section>
        <section className="mb-8">
          <h2 className="font-bold text-2xl mb-2">Linki</h2>
          <div className="flex gap-3 flex-wrap">
            {socials?.map((s, i) => (
              <a key={i} href={s.url} className="text-blue-600 underline" target="_blank" rel="noopener">{s.label}</a>
            ))}
          </div>
        </section>
        <footer className="text-center mt-12 text-gray-600">
          Kontakt: <a href={`mailto:${contact?.email}`}>{contact?.email}</a>
        </footer>
      </main>
    </div>
  );
}
