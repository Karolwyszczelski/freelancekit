'use client'
import { usePortfolioWizard } from '../app/portfolio-wizard/PortfolioWizardContext'
import WizardStepsNav from '../components/PortfolioWizardProvider/PortfolioWizardModal/WizardStepsNav'
import Step1ChooseTemplate from './PortfolioWizardProvider/PortfolioWizardModal/Step1ChooseTemplate'
import Step2AboutMe from './PortfolioWizardProvider/PortfolioWizardModal/Step2AboutMe'
import Step3Projects from './PortfolioWizardProvider/PortfolioWizardModal/Step3Projects'
import Step4LinksContact from './PortfolioWizardProvider/PortfolioWizardModal/Step4LinksContact'
import Step5SeoSlug from './PortfolioWizardProvider/PortfolioWizardModal/Step5SeoSlug'
import Step6Preview from './PortfolioWizardProvider/PortfolioWizardModal/Step6Preview'

export default function PortfolioWizardModal({ onPublish }) {
  const { state, setState } = usePortfolioWizard()

  function next() { if (state.step < 6) setState(p => ({ ...p, step: p.step + 1 })); }
  function prev() { if (state.step > 1) setState(p => ({ ...p, step: p.step - 1 })); }

  return (
    <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center px-2">
      <div className="bg-gradient-to-br from-white/70 to-purple-100/80 rounded-3xl max-w-3xl w-full shadow-2xl p-8 relative">
        <WizardStepsNav />
        <div className="mt-2">
          {state.step === 1 && <Step1ChooseTemplate />}
          {state.step === 2 && <Step2AboutMe />}
          {state.step === 3 && <Step3Projects />}
          {state.step === 4 && <Step4LinksContact />}
          {state.step === 5 && <Step5SeoSlug />}
          {state.step === 6 && <Step6Preview onPublish={onPublish} />}
        </div>
        {state.step < 6 && (
          <div className="flex justify-between mt-6">
            <button onClick={prev} disabled={state.step === 1} className="px-6 py-2 rounded-xl bg-gray-200 text-gray-600">
              Wstecz
            </button>
            <button onClick={next} className="px-6 py-2 rounded-xl bg-purple-500 text-white font-semibold">
              Dalej
            </button>
          </div>
        )}
        {/* Przycisk zamknięcia */}
        <button className="absolute top-3 right-4 text-2xl text-gray-400 hover:text-gray-600"
                onClick={() => setState((prev) => ({...prev, step: 1}))}>×</button>
      </div>
    </div>
  )
}
