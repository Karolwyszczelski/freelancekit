export default function CreativeTemplate({ demo = false }) {
  return (
    <div className="w-full h-full p-2 bg-pink-100 rounded-xl border border-pink-300 flex flex-col items-center justify-center shadow-md">
      <div className="w-16 h-16 rounded-full bg-pink-300 mb-2 shadow-xl" />
      <div className="font-extrabold text-pink-800 text-base">Anna Artystyczna</div>
      <div className="text-sm text-pink-700 mb-2">Ilustrator • Artysta</div>
      <div className="w-24 h-4 bg-white/80 rounded mb-1"></div>
      <div className="w-20 h-4 bg-pink-200 rounded"></div>
    </div>
  )
}
