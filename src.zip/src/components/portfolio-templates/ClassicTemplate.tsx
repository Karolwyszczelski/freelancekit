export default function ClassicTemplate({ demo = false }) {
  return (
    <div className="w-full h-full p-2 bg-white rounded-xl border border-gray-200 flex flex-col items-center justify-center">
      <div className="w-16 h-16 rounded-full bg-gray-200 mb-2" />
      <div className="font-bold text-gray-700 text-base">Jan Kowalski</div>
      <div className="text-sm text-gray-500 mb-2">Web Developer</div>
      <div className="w-24 h-4 bg-gray-100 rounded mb-1"></div>
      <div className="w-20 h-4 bg-gray-100 rounded"></div>
    </div>
  )
}
