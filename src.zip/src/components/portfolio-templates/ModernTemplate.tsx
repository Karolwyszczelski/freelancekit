export default function ModernTemplate({ demo = false }) {
  return (
    <div className="w-full h-full p-2 bg-gradient-to-br from-blue-200 to-purple-200 rounded-xl border border-gray-200 flex flex-col items-center justify-center shadow-inner">
      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-blue-400 mb-2" />
      <div className="font-bold text-blue-900 text-base">Jan Nowoczesny</div>
      <div className="text-sm text-blue-700 mb-2">Designer UI/UX</div>
      <div className="w-24 h-4 bg-white/80 rounded mb-1"></div>
      <div className="w-20 h-4 bg-white/60 rounded"></div>
    </div>
  )
}
