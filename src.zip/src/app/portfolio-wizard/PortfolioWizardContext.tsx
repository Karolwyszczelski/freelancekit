// app/dashboard/portfolio-wizard/page.tsx
'use client'
import { useState } from 'react'
import ClassicTemplate from '@/components/portfolio-templates/ClassicTemplate'
import ModernTemplate from '@/components/portfolio-templates/ModernTemplate'
import CreativeTemplate from '@/components/portfolio-templates/CreativeTemplate'

const templates = [
  {
    key: 'classic',
    name: 'Classic',
    description: 'Czysty, profesjonalny wygląd – idealny dla ekspertów i konsultantów.',
    component: <ClassicTemplate demo />,
  },
  {
    key: 'modern',
    name: 'Modern',
    description: 'Nowoczesny, dynamiczny styl – mocne kolory i przejrzyste sekcje.',
    component: <ModernTemplate demo />,
  },
  {
    key: 'creative',
    name: 'Creative',
    description: 'Artystyczny layout, niestandardowa typografia i pastelowe kolory.',
    component: <CreativeTemplate demo />,
  },
]

export default function PortfolioWizardStep1() {
  const [selected, setSelected] = useState('classic')

  return (
    <div className="flex min-h-screen w-full">
      {/* Sidebar zostaje (jest w layoutcie) */}
      <div className="flex-1 bg-gradient-to-br from-[#7e4fff] via-[#99caff] to-[#0dd4ed] flex items-center justify-center transition-all">
        <div className="bg-white/90 rounded-3xl shadow-2xl p-12 w-full max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Stwórz swoje portfolio</h1>

          {/* Krokowy pasek postępu */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-purple-600 text-white font-bold">1</div>
            <span className="font-semibold text-purple-700">Wybierz szablon</span>
            <div className="w-8 h-[2px] bg-purple-300 mx-2" />
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-200 text-gray-600">2</div>
            <span className="text-gray-500">Dane</span>
            <div className="w-8 h-[2px] bg-gray-200 mx-2" />
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-200 text-gray-600">3</div>
            <span className="text-gray-500">Projekty</span>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4 text-center">Wybierz szablon</h2>
            <div className="flex gap-8 flex-wrap justify-center">
              {templates.map(t => (
                <button
                  key={t.key}
                  onClick={() => setSelected(t.key)}
                  className={`relative w-60 rounded-2xl shadow-lg transition 
                    ${selected === t.key ? "ring-4 ring-purple-400 scale-105" : "hover:ring-2 hover:ring-purple-300"}
                    bg-white/80 flex flex-col items-center p-5`}
                  type="button"
                >
                  <div className="h-40 w-full mb-4 overflow-hidden rounded-xl border border-gray-100 flex items-center justify-center">
                    {/* Mini podgląd szablonu */}
                    <div className="scale-90 origin-top">{t.component}</div>
                  </div>
                  <div className="font-semibold mb-1">{t.name}</div>
                  <div className="text-xs text-gray-500 text-center">{t.description}</div>
                  {selected === t.key && (
                    <div className="absolute -top-3 right-4 bg-purple-600 text-white px-2 py-0.5 rounded-xl text-xs shadow">
                      Wybrano
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end mt-8">
            <button
              className="bg-purple-600 hover:bg-purple-700 text-white px-12 py-3 rounded-xl font-semibold shadow transition text-lg"
              onClick={() => window.location.href = `/dashboard/portfolio-wizard/data?template=${selected}`}
            >
              Dalej
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
