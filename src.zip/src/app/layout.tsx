'use client';
import './globals.css'
import Link from 'next/link'
import { ReactNode } from 'react'

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pl" className="dark">
      <head />
      <body className="min-h-screen flex flex-col">
        <header className="p-4 flex justify-between items-center bg-white/10 backdrop-blur-xs">
          <h1 className="text-2xl font-bold">FreelanceKit</h1>
          <nav className="space-x-4">
            <Link href="/" className="hover:underline">Start</Link>
            <Link href="/login" className="hover:underline">Logowanie</Link>
          </nav>
        </header>
        <main className="flex-1">
          {children}
        </main>
      </body>
    </html>
  )
}
