import OfferAIForm from '../../../components/OfferAIForm'

export default function OfferPage() {
  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-200 to-purple-200">
      <OfferAIForm />
    </div>
  )
}
