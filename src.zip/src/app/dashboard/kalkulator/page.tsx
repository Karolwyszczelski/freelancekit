export default function KalkulatorPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold">Kalkulator wycen usług</h1>
      <p className="mt-4">Tu wstawimy formularz wyliczający cenę na podstawie parametrów.</p>
    </div>
  )
}
