'use client'
import { ReactNode, useEffect } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { useRouter } from 'next/navigation'
import Sidebar from '../../components/sidebar'

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const router = useRouter()

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) router.replace('/login')
    })
  }, [router])

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-blue-600 to-purple-600">
      <Sidebar />
      <div className="flex-1 p-6">
        {children}
      </div>
    </div>
  )
}
