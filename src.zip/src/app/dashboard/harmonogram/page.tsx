'use client'
import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { supabase } from '../../../lib/supabaseClient'
import AddEditScheduleModal from '../../../components/AddEditScheduleModal'
import { ScheduleItem } from '../../types'

// Godziny w siatce
const HOURS = Array.from({ length: 10 }, (_, i) => 8 + i) // 8:00-17:00

// Kolory eventów
const eventColors: Record<string, string> = {
  Instagram: '#74b9ff',
  Facebook: '#fdcb6e',
  LinkedIn: '#0984e3',
  TikTok: '#000000',
  YouTube: '#ff7675',
  X: '#333333',
  Wydarzenie: '#a29bfe',
  Kampania: '#00b894',
  default: '#b2bec3'
}

// Nazwy dni tygodnia (PL)
const WEEKDAYS_SHORT = ['pon', 'wt', 'śr', 'czw', 'pt', 'sob', 'nd']

// Funkcja: poniedziałek tygodnia dla danej daty
const getStartOfWeek = (date: Date) => {
  const d = new Date(date)
  const day = d.getDay() === 0 ? 6 : d.getDay() - 1 // PL: pon = 0
  d.setDate(d.getDate() - day)
  d.setHours(0, 0, 0, 0)
  return d
}

// Generowanie dni tygodnia (7 dni od poniedziałku)
const getWeekDays = (date: Date) => {
  const start = getStartOfWeek(date)
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start)
    d.setDate(d.getDate() + i)
    return d
  })
}

// Mini-kalendarz do wyboru tygodnia
function MiniCalendar({ selected, onChange }: { selected: Date, onChange: (date: Date) => void }) {
  const now = new Date()
  const [month, setMonth] = useState(new Date(selected.getFullYear(), selected.getMonth(), 1))
  const firstDay = getStartOfWeek(new Date(month))
  const allDays = Array.from({ length: 42 }, (_, i) => {
    const d = new Date(firstDay)
    d.setDate(d.getDate() + i)
    return d
  })
  return (
    <div className="p-3 rounded-2xl bg-white/80 shadow-lg border border-white/40 flex flex-col items-center z-20 absolute left-0 top-full mt-2">
      <div className="flex gap-2 mb-2">
        <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} className="p-1 px-2 rounded-lg text-gray-600 hover:bg-blue-100">&lt;</button>
        <span className="font-semibold">{month.toLocaleString('pl-PL', { month: 'long', year: 'numeric' })}</span>
        <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="p-1 px-2 rounded-lg text-gray-600 hover:bg-blue-100">&gt;</button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs w-full">
        {WEEKDAYS_SHORT.map(d => <div key={d} className="font-bold text-gray-700">{d}</div>)}
        {allDays.map((d, idx) => (
          <button
            key={idx}
            onClick={() => onChange(getStartOfWeek(d))}
            className={`
              w-8 h-8 rounded-xl
              ${d.getMonth() === month.getMonth() ? 'bg-white/80 text-gray-900' : 'text-gray-300'}
              ${getStartOfWeek(selected).toDateString() === getStartOfWeek(d).toDateString() ? 'bg-blue-500/80 text-white font-bold' : ''}
              ${d.toDateString() === now.toDateString() ? 'ring-2 ring-blue-400' : ''}
              hover:bg-blue-200 transition`}
            tabIndex={-1}
          >
            {d.getDate()}
          </button>
        ))}
      </div>
    </div>
  )
}

export default function SchedulePage() {
  const [items, setItems] = useState<ScheduleItem[]>([])
  const [type, setType] = useState('Wszystkie')
  const [channel, setChannel] = useState('Wszystkie')
  const [status, setStatus] = useState('Wszystkie')
  const [editing, setEditing] = useState<ScheduleItem | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [weekMonday, setWeekMonday] = useState(getStartOfWeek(new Date()))
  const [showCalendar, setShowCalendar] = useState(false)
  const [viewMode, setViewMode] = useState<'week' | 'day' | 'month'>('week')
  const today = new Date()

  // Drag&Drop
  const [dragging, setDragging] = useState<{ event: ScheduleItem } | null>(null)

  // Tooltip z createPortal (poprawny UX!)
  const [tooltip, setTooltip] = useState<{ x: number, y: number, content: JSX.Element } | null>(null)
  let tooltipTimeout: any

  // Pobierz dane z Supabase
  const fetchData = async () => {
    let query = supabase.from('schedule').select('*')
    if (type !== 'Wszystkie') query = query.eq('type', type)
    if (channel !== 'Wszystkie') query = query.eq('channel', channel)
    if (status !== 'Wszystkie') query = query.eq('status', status)
    const { data } = await query
    setItems(data || [])
  }

  useEffect(() => {
    fetchData()
    const ch = supabase
      .channel('schedule-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'schedule' }, fetchData)
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [type, channel, status])

  const weekDays = getWeekDays(weekMonday)

  // Znajdź wpis dla danego dnia/godziny
  const getItem = (date: Date, hour: number) =>
    items.filter(
      i =>
        new Date(i.date).toDateString() === date.toDateString() &&
        Number(i.time.split(':')[0]) === hour
    )

  // Czy dzień to dziś
  const isToday = (d: Date) =>
    d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()

  // Liczba eventów w danym dniu
  const countEvents = (date: Date) =>
    items.filter(i => new Date(i.date).toDateString() === date.toDateString()).length

  // DRAG & DROP handlers
  function handleDragStart(ev: React.DragEvent, event: ScheduleItem) {
    setDragging({ event })
    ev.dataTransfer.effectAllowed = 'move'
    ev.dataTransfer.setData('text/plain', event.id)
  }
  async function handleDrop(ev: React.DragEvent, date: Date, hour: number) {
    ev.preventDefault()
    setDragging(null)
    const id = ev.dataTransfer.getData('text/plain')
    // Update event na nową datę/godzinę
    const { error } = await supabase.from('schedule').update({
      date: date.toISOString().slice(0, 10),
      time: hour.toString().padStart(2, "0") + ':00'
    }).eq('id', id)
    if (!error) fetchData()
  }
  function handleDragOver(ev: React.DragEvent) {
    ev.preventDefault()
    ev.dataTransfer.dropEffect = 'move'
  }

  // Tooltip
  function showTooltip(e: React.MouseEvent, content: JSX.Element) {
    const rect = (e.target as HTMLElement).getBoundingClientRect()
    setTooltip({
      x: rect.right + 12,
      y: rect.top + window.scrollY,
      content,
    })
    clearTimeout(tooltipTimeout)
  }
  function hideTooltip() {
    tooltipTimeout = setTimeout(() => setTooltip(null), 80)
  }

  // Klonowanie eventu
  const cloneEvent = async (ev: ScheduleItem, targetDate: Date, targetHour: number) => {
    const { id, ...rest } = ev
    const newEv = {
      ...rest,
      date: targetDate.toISOString().slice(0, 10),
      time: targetHour.toString().padStart(2, "0") + ':00'
    }
    const { error } = await supabase.from('schedule').insert([newEv])
    if (!error) fetchData()
  }

  // Widoki:
  return (
    <div className="min-h-screen flex items-center justify-center"
      style={{ background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)" }}>
      <div className="rounded-[32px] p-4 sm:p-6 md:p-10 bg-white/30 shadow-2xl backdrop-blur-[10px] border border-white/20 max-w-5xl w-full"
        style={{
          boxShadow: "0 8px 40px 0 rgba(50, 50, 200, 0.12), 0 1.5px 4px #fff3"
        }}>
        {/* Nagłówek i tryby widoku */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <h2 className="text-3xl font-bold text-black">Harmonogram</h2>
          <div className="flex gap-2">
            <button
              className="flex items-center gap-2 px-6 py-2 bg-blue-500/80 hover:bg-blue-500 text-white font-semibold text-base rounded-2xl shadow transition"
              onClick={() => { setEditing(null); setShowModal(true) }}>
              <span className="text-xl font-bold">+</span> Dodaj
            </button>
            <select value={viewMode} onChange={e => setViewMode(e.target.value as any)} className="bg-white/80 rounded-xl shadow px-2 py-1 ml-2 text-base border-0 focus:ring-2 focus:ring-blue-400 transition">
              <option value="week">Tydzień</option>
              <option value="day">Dzień</option>
              <option value="month">Miesiąc</option>
            </select>
          </div>
        </div>

        {/* Nawigacja tygodnia */}
        {viewMode === "week" && (
          <div className="flex items-center justify-between mb-7">
            <div className="flex gap-2 items-center relative">
              <button className="px-3 py-1 rounded-xl bg-white/60 hover:bg-blue-200 text-blue-700 font-bold shadow"
                onClick={() => setWeekMonday(new Date(weekMonday.getFullYear(), weekMonday.getMonth(), weekMonday.getDate() - 7))}>←</button>
              <button className="px-3 py-1 rounded-xl bg-white/60 hover:bg-blue-200 text-blue-700 font-bold shadow"
                onClick={() => setWeekMonday(getStartOfWeek(new Date()))}>Dzisiaj</button>
              <button className="px-3 py-1 rounded-xl bg-white/60 hover:bg-blue-200 text-blue-700 font-bold shadow"
                onClick={() => setWeekMonday(new Date(weekMonday.getFullYear(), weekMonday.getMonth(), weekMonday.getDate() + 7))}>→</button>
              <button className="ml-2 px-3 py-1 rounded-xl bg-white/70 hover:bg-blue-100 text-blue-700 font-bold shadow relative"
                onClick={() => setShowCalendar(x => !x)}>📅</button>
              {showCalendar &&
                <MiniCalendar selected={weekMonday} onChange={date => { setWeekMonday(date); setShowCalendar(false) }} />
              }
            </div>
            <div className="text-gray-700 font-semibold text-base">
              {weekDays[0].toLocaleDateString('pl-PL', { day: '2-digit', month: 'short', year: 'numeric' })} – {weekDays[6].toLocaleDateString('pl-PL', { day: '2-digit', month: 'short', year: 'numeric' })}
            </div>
          </div>
        )}

        {/* Filtry */}
        <div className="flex flex-wrap gap-4 mb-7">
          <select value={type} onChange={e => setType(e.target.value)} className="p-3 px-5 rounded-xl bg-white/80 text-base shadow border-0 focus:ring-2 focus:ring-blue-400 transition">
            <option>Wszystkie</option>
            <option>Post</option>
            <option>Wydarzenie</option>
            <option>Kampania</option>
          </select>
          <select value={channel} onChange={e => setChannel(e.target.value)} className="p-3 px-5 rounded-xl bg-white/80 text-base shadow border-0 focus:ring-2 focus:ring-blue-400 transition">
            <option>Wszystkie</option>
            <option>Instagram</option>
            <option>Facebook</option>
            <option>LinkedIn</option>
            <option>TikTok</option>
            <option>YouTube</option>
            <option>X</option>
          </select>
          <select value={status} onChange={e => setStatus(e.target.value)} className="p-3 px-5 rounded-xl bg-white/80 text-base shadow border-0 focus:ring-2 focus:ring-blue-400 transition">
            <option>Wszystkie</option>
            <option>Zaplanowane</option>
            <option>Opublikowane</option>
          </select>
        </div>

        {/* Widok TYGODNIOWY z DnD i tooltipem */}
        {viewMode === "week" && (
          <div className="relative overflow-x-auto">
            {/* Siatka SVG w tle */}
            <div className="absolute inset-0 pointer-events-none z-0" aria-hidden>
              <svg width="100%" height="100%" className="w-full h-full" style={{ minHeight: 520 }}>
                {weekDays.map((_, i) => (
                  <line
                    key={i}
                    x1={`${(i + 1) * (100 / 8)}%`} x2={`${(i + 1) * (100 / 8)}%`}
                    y1="0" y2="100%"
                    stroke="#8b5cf655" strokeWidth="1" />
                ))}
                {HOURS.map((_, i) => (
                  <line
                    key={i}
                    x1="0" x2="100%"
                    y1={`${(i + 1) * (100 / HOURS.length)}%`} y2={`${(i + 1) * (100 / HOURS.length)}%`}
                    stroke="#8b5cf655" strokeWidth="1" />
                ))}
              </svg>
            </div>
            <div className="grid grid-cols-8 min-w-[1120px] z-10 relative select-none">
              {/* Dni tygodnia */}
              <div />
              {weekDays.map((day, idx) => (
                <div
                  key={idx}
                  className={`text-center text-base font-semibold pb-2 relative ${isToday(day) ? "text-blue-700 underline underline-offset-4" : "text-gray-700"}`}
                  style={{ cursor: 'pointer' }}
                  title="Kliknij by zobaczyć podsumowanie dnia"
                  onClick={() => alert(`Podgląd dnia: ${day.toLocaleDateString('pl-PL')}\nWydarzenia: ${countEvents(day)}`)}
                >
                  {day.toLocaleDateString('pl-PL', { weekday: 'short', day: '2-digit', month: '2-digit' })}
                  {countEvents(day) > 0 && (
                    <span className="absolute -top-2 right-1 bg-blue-500 text-white text-xs rounded-full px-1.5 py-0.5">{countEvents(day)}</span>
                  )}
                </div>
              ))}
              {/* Siatka godzin i eventów */}
              {HOURS.map(hour => (
                <div className="contents" key={hour}>
                  <div className="text-right text-sm font-medium text-gray-500 pr-3 py-2">{hour}:00</div>
                  {weekDays.map((day, idx) => {
                    const events = getItem(day, hour)
                    return (
                      <div
                        key={day.toISOString() + hour}
                        className={`py-2 flex items-center justify-center min-h-[56px] group relative ${isToday(day) ? 'bg-blue-50/40' : ''}`}
                        onDrop={e => handleDrop(e, day, hour)}
                        onDragOver={handleDragOver}
                      >
                        {events.map((item, i) => (
                          <div
                            key={item.id || i}
                            className="rounded-xl px-4 py-2 font-semibold text-white shadow-md text-sm cursor-pointer group-hover:scale-[1.03] transition"
                            draggable
                            onDragStart={ev => handleDragStart(ev, item)}
                            onClick={() => { setEditing(item); setShowModal(true) }}
                            onMouseEnter={e => showTooltip(e, (
                              <div className="bg-white/95 p-4 rounded-xl shadow-xl border border-blue-200 min-w-[240px] max-w-[340px]">
                                <div className="font-bold text-base text-black">{item.title}</div>
                                <div className="text-xs text-gray-500 mb-2">{item.date} {item.time}</div>
                                {item.description && <div className="text-sm mb-1">{item.description}</div>}
                                {item.hashtags && item.hashtags.length > 0 && (
                                  <div className="mb-1">
                                    <span className="font-semibold text-xs">#</span>{" "}
                                    {item.hashtags.map((h: string, idx: number) => (
                                      <span key={h + idx} className="inline-block bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs mr-1">{h}</span>
                                    ))}
                                  </div>
                                )}
                                {item.notes && item.notes.length > 0 && (
                                  <div className="mb-1 text-xs text-gray-700">Notatki: {item.notes.join(", ")}</div>
                                )}
                                {item.attachments && item.attachments.length > 0 && (
                                  <div className="mb-1 text-xs">Załączniki: {item.attachments.map((a: string, idx: number) => (
                                    <a key={a + idx} href={a} className="underline ml-1" target="_blank" rel="noopener">{a.slice(0, 16)}...</a>
                                  ))}</div>
                                )}
                                {item.reminder_time && <div className="mb-1 text-xs">⏰ Powiadomienie: {item.reminder_time.replace("T", " ")}</div>}
                                {item.is_important && <div className="mb-1 text-xs text-pink-600 font-bold">Priorytet!</div>}
                                {/* Szybkie akcje */}
                                <div className="flex gap-2 mt-2">
                                  <button
                                    className="px-2 py-1 rounded bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs"
                                    onClick={() => { setEditing(item); setShowModal(true); setTooltip(null) }}
                                  >Edytuj</button>
                                  <button
                                    className="px-2 py-1 rounded bg-green-100 hover:bg-green-200 text-green-700 text-xs"
                                    onClick={() => { cloneEvent(item, day, hour); setTooltip(null) }}
                                  >Sklonuj do tej komórki</button>
                                </div>
                              </div>
                            ))}
                            onMouseLeave={hideTooltip}
                            style={{
                              background: eventColors[item.channel] || eventColors[item.type] || eventColors.default,
                              boxShadow: "0 1.5px 8px 0 rgba(30,30,70,0.08)"
                            }}
                          >
                            {item.title}
                            {item.description && (
                              <div className="text-xs font-normal text-white/90 mt-1">{item.description}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    )
                  })}
                </div>
              ))}
            </div>
            {/* TOOLTIP z PORTALEM */}
            {tooltip && createPortal(
              <div
                style={{
                  position: 'absolute',
                  left: Math.min(tooltip.x, window.innerWidth - 360),
                  top: Math.max(tooltip.y, 12),
                  zIndex: 9999
                }}
                onMouseEnter={() => clearTimeout(tooltipTimeout)}
                onMouseLeave={hideTooltip}
              >
                {tooltip.content}
              </div>,
              typeof window !== "undefined" ? document.body : (null as any)
            )}
          </div>
        )}

        {/* Widok dzień */}
        {viewMode === "day" && (
          <div className="p-4 rounded-2xl bg-white/50 shadow-md mt-3">
            <h3 className="font-bold mb-2 text-lg">
              {weekDays.find(d => isToday(d))?.toLocaleDateString('pl-PL', { weekday: "long", day: "2-digit", month: "long" }) || "Dzień"}
            </h3>
            <ul>
              {items.filter(i => isToday(new Date(i.date))).length === 0 && (
                <li className="text-gray-500 italic">Brak wydarzeń na dziś.</li>
              )}
              {items.filter(i => isToday(new Date(i.date))).map(i => (
                <li key={i.id} className="mb-3 bg-blue-50 rounded-xl px-4 py-2 shadow flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="font-semibold text-base text-black">{i.title}</div>
                    <div className="text-xs text-gray-600">{i.time}</div>
                    <div className="text-sm text-gray-700">{i.description}</div>
                  </div>
                  <button
                    className="px-3 py-1 bg-blue-500/90 text-white rounded-xl text-xs mt-2 sm:mt-0"
                    onClick={() => { setEditing(i); setShowModal(true) }}
                  >Edytuj</button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Widok miesiąc */}
        {viewMode === "month" && (
          <div className="p-4 rounded-2xl bg-white/50 shadow-md mt-3">
            <h3 className="font-bold mb-2 text-lg">
              {weekMonday.toLocaleDateString('pl-PL', { month: "long", year: "numeric" })}
            </h3>
            <div className="grid grid-cols-7 gap-3">
              {Array.from({ length: 31 }, (_, i) => {
                const d = new Date(weekMonday.getFullYear(), weekMonday.getMonth(), i + 1)
                const dayEvents = items.filter(ev => new Date(ev.date).toDateString() === d.toDateString())
                return (
                  <div key={i} className={`rounded-xl p-2 min-h-[64px] flex flex-col bg-white/80 ${isToday(d) ? 'ring-2 ring-blue-400' : ''}`}>
                    <div className="text-xs font-semibold text-gray-800 mb-1">{d.getDate()}</div>
                    {dayEvents.map(ev => (
                      <div key={ev.id} className="bg-blue-200/70 text-xs text-blue-800 rounded px-2 py-0.5 mb-1 cursor-pointer" onClick={() => { setEditing(ev); setShowModal(true) }}>
                        {ev.title}
                      </div>
                    ))}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <AddEditScheduleModal
            initial={editing}
            onClose={() => setShowModal(false)}
            onSaved={fetchData}
          />
        )}
      </div>
    </div>
  )
}
