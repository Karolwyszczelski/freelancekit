export default function ProjektyPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold">Tablica projektów (Kanban)</h1>
      <p className="mt-4">Tu pojawi się drag & drop board (react-kanban / custom).</p>
    </div>
  )
}
