export default function PortfolioPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold">Mini-portfolio</h1>
      <p className="mt-4">Tu użytkownik skonfiguruje swoją stronę-wizytówkę z CTA.</p>
    </div>
  )
}
