// app/dashboard/page.tsx
'use client'

import TrendWidget from '../../components/TrendWidget'
import { GlassCard } from '../../components/GlassCard'
import TasksWidget from '../../components/TasksWidget'
import ScheduleWidget from '../../components/ScheduleWidget'
import NotificationsWidget from '@/components/NotificationsWidget'
import { Calendar, CheckSquare, Bell } from 'lucide-react'

// Przykładowy userId do testów (później pobierzesz z sesji/usera Supabase)
const USER_ID = "test-user-id"

export default function DashboardPage() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 max-w-7xl mx-auto">
      {/* Trendy na 2025 */}
      <GlassCard className="h-80 p-6 flex flex-col col-span-1">
        <h2 className="text-white text-xl font-semibold mb-4">Trendy na 2025</h2>
        <div className="flex-1 flex items-center justify-center">
          <TrendWidget />
        </div>
      </GlassCard>

      {/* Harmonogram */}
      <GlassCard className="h-80 p-6 flex flex-col col-span-1">
        <h2 className="text-white text-xl font-semibold mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5" /> Harmonogram
        </h2>
        <div className="flex-1">
          <ScheduleWidget />
        </div>
      </GlassCard>

      {/* Mała kolumna na Zadania i Powiadomienia */}
      <div className="flex flex-col gap-6 col-span-1">
        {/* Zadania - mały widget */}
        <GlassCard className="h-36 p-4 flex flex-col">
          <h2 className="text-white text-lg font-semibold mb-2 flex items-center gap-2">
            <CheckSquare className="w-5 h-5" /> Zadania
          </h2>
          <div className="flex-1 overflow-auto">
            <TasksWidget small />
          </div>
        </GlassCard>
        {/* Powiadomienia - mały widget */}
        <GlassCard className="h-36 p-4 flex flex-col">
          <h2 className="text-white text-lg font-semibold mb-2 flex items-center gap-2">
            <Bell className="w-5 h-5" /> Powiadomienia
          </h2>
          <div className="flex-1 overflow-auto">
            <NotificationsWidget userId={USER_ID} small />
          </div>
        </GlassCard>
      </div>
    </div>
  )
}
