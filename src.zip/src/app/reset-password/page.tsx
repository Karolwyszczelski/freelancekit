// app/reset-password/page.tsx
'use client';
export default function ResetPasswordPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <p>🔑 Strona odzyskiwania hasła (tu formularz reset-password)</p>
    </div>
  )
}
